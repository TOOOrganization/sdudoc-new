'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_HOST: "http://211.87.232.198:8081"
}
